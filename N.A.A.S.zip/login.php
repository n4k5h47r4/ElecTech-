<!DOCTYPE html>
<html lang="en">
<head>
<style>
      body {
        text-align: center;
      }
      input {
        border-width: 1px;
        border-style: solid;
        border-color: rgb(200, 200, 200);
        padding-top: 12px;
        padding-bottom: 12px;
        padding-left: 16px;
        padding-right: 16px;
        font-size: 16px;
        border-radius: 8px;
        margin-bottom: 12px;
      }

      .first-name {
        width: 148px;
      }

      .last-name {
        width: 148px;
      }

      .email {
        width: 300px;
      }

      button {
        background-color: rgb(47, 127, 231);
        color: white;
        border: none;
        width: 300px;
        padding-top: 14px;
        padding-bottom: 14px;
        font-size: 18px;
        font-weight: bold;
        border-radius: 8px;
      }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electech - loign portal</title>

    
    <!--BOOTSTRAP CONNECT-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

</head>
<body>

    
    <center>
    <div class="container my-4 ">
    
    <h1 class="text-center">LOGIN Here</h1> 
    <form action="login.php" method="post">
    
        <div class="username_css"> 
            <label for="username">Username</label> 
        <input type="text" class="form-control" id="username"
            name="username" aria-describedby="emailHelp">    
        </div>
        <br>
        <div class="password_css"> 
            <label for="password">Password</label> 
            <input type="password" class="form-control"
            id="password" name="password"> 
        </div>
        <br>
        <div class="email_css"> 
            <label for="email">Email</label> 
            <input type="email" class="form-control"
            id="email" name="email"> 
        </div>
        <br>
        <button type="submit" class="btn btn-primary" class="text-center">
        Log in
        </button> 
    </form> 
</div>
    </center>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>