<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Community </title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"></link>

</head>
<body>
<style>
  .child2{
    display: flex;
    justify-content: space-around;
    align-items: center;
    flex-wrap: wrap;
    
  }
</style>

<header class = "header">
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">COMMUNITY</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="home.php">HOME</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            List
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Manufacturer</a></li>
            <li><a class="dropdown-item" href="#">Lithium battery providers</a></li>
            <li><a class="dropdown-item" href="#">EV charging companies</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Investors</a></li>
          </ul>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="SEARCH" class="text-right">
        <button class="btn btn-outline-success" type="submit">Name</button>
      </form>
    </div>
  </div>
</nav> 
</header>

<div class="child2">
<div class="card" style="width: 18rem;" class="p-5">
  <img src="img/evgo.jpeg" class="card-img-top" alt="..." >
  <div class="card-body">
    <h5 class="card-title"> EVGO</h5>
    <p class="card-text">EV charging station provider</p>
    <a href="#" class="btn btn-primary">Connect</a>
  </div>
</div>

<div class="card" style="width: 18rem;" class="p-5">
  <img src="img/elon.jpg" class="card-img-top" alt="..." >
  <div class="card-body">
    <h5 class="card-title"> Elon Musk</h5>
    <p class="card-text">Investor</p>
    <a href="#" class="btn btn-primary">Connect</a>
  </div>
</div>

<div class="card" style="width: 18rem;" class="p-5">
  <img src="img/comp.jpeg" class="card-img-top" alt="..." >
  <div class="card-body">
    <h5 class="card-title"> E Components</h5>
    <p class="card-text">All electric vehicle components</p>
    <a href="#" class="btn btn-primary">Connect</a>
  </div>
</div>

<div class="card" style="width: 18rem;" class="p-5">
  <img src="img/battrix.jpeg" class="card-img-top" alt="..." >
  <div class="card-body">
    <h5 class="card-title"> Battrix</h5>
    <p class="card-text">Lithium Battery providers</p>
    <a href="#" class="btn btn-primary">Connect</a>
  </div>
</div>

</div>



<!--BOOTSTRAP JAVA LINK-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
